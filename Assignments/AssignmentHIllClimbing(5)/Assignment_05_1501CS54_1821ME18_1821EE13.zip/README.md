## HILL Climbing 
Code:  `python HIllClimbing.py`
1. Parameters to change are following : 
- input file name `line no 659`
- output file name `line no 660`
- Heursitics function `line no 716`


## Simulated Annealing 
Code : `python SA.py`
1. Parameters to change are following:
- input file name `line no `
- output file name `line no`
-heurisitc funtion `line no`
-suggested values 
```
Temp : >1
Min Temp : >1e-4
Select the cooling function and alpha, Enter the function chocie : 
>1
Input : Alpha >.9999
```