## Important files : 
1. `main.py` is the file to be run 
2.  In the `main.py` file assign the expression to `Expr` varaible for which to wish to prove on the line `154`
3.  If you get `TRUE` in the end output -> that the theorem is proved
