## Checkpoints
- [X] Implement the reading of the file for start and the goal state
- [X] Implement the heuristic functions
- [X] Implement the action function
- [] Contain everything in single class

