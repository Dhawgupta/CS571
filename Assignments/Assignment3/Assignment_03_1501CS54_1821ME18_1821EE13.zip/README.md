## Info

1. `check_montonicity.py` : for monotonic heuristic
2. `check_monotonicity_2.py` : for non monotonic heurisitc